## Beneventi Tommaso
- Issues #12, #22 (GUI navigation)
## Donov Kyrylo
- Issues #8, #20 (JSON class, maze return algorithm)
## Melis Riccardo
- Issues #7, #19 (REST class, maze exploration algorithm)
## Molinari Simone
- Issues #6, #22 (GUI navigation, maze loading)
## Shehab Adam
- Issues #5, #18 (GUI prototype)
