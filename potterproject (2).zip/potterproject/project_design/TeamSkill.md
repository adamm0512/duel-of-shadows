# Team skill
1. Melis Riccardo(owner): 
- advanced programming skills 
- team leader skills
2. Donov Kyrylo (developer): 
- advanced programming skills 
- GitLab knowledge
3. Shehab Adam(developer): 
- english knowledge 
- teamwork skills
4. Molinari Simone(developer): 
- advanced english skills 
- good programming skills
5. Beneventi Tommaso(developer): 
- teamwork skills 
- all-around skills
