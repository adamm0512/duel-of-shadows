package potterproject;

public class UnloadResult {

    private String status;

    private int energy;

    public UnloadResult(JSON result) {
    }
}
