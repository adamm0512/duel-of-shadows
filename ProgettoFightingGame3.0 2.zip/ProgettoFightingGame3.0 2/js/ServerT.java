//non è ancora stato modificato per il gioco di rete
import java.io.*;
import java.net.*;
public class ServerT {
    /*
     public void connetti() {
        try (ServerSocket serverSocket = new ServerSocket(6789)) {
            System.out.println("SERVER partito in attesa su porta 6789...");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Client connesso: porta virtuale su cui � collegato il CLIENT: " + socket.getPort());
                System.out.println("SERVER: Agganciato NUOVO Client avente socket: " + socket);
                System.out.println("----------------------------------------------------------------- ");

                ThreadTCP serverThread = new ThreadTCP(socket);
                serverThread.start();
            }
        } catch (IOException e) {
            System.out.println("Errore durante l'istanza del server: " + e.getMessage());
            System.exit(1);
        }
    }*/
   //stessa cosa di sopra ma con 2 client
    public void connetti() {
        try (ServerSocket serverSocket = new ServerSocket(6789)) {
            System.out.println("SERVER partito in attesa su porta 6789...");

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Client connesso: porta virtuale su cui � collegato il CLIENT: " + socket.getPort());
                System.out.println("SERVER: Agganciato NUOVO Client avente socket: " + socket);
                System.out.println("----------------------------------------------------------------- ");
                Socket socket2 = serverSocket.accept();
                System.out.println("Client connesso: porta virtuale su cui � collegato il CLIENT: " + socket2.getPort());
                System.out.println("SERVER: Agganciato NUOVO Client avente socket: " + socket2);
                System.out.println("----------------------------------------------------------------- ");

                ThreadTCP serverThread1 = new ThreadTCP(socket);
                ThreadTCP serverThread2 = new ThreadTCP(socket2);
                serverThread1.start();
                serverThread2.start();
                //stessa cosa ma i client non compaiono esattamente nello stesso momento
                //prendo da entrambi i serverThread i dati e li scambio tra i due e poi li rimando ai client
                String temp1 = serverThread1.getDatifromServer();
                String temp2 = serverThread2.getDatifromServer();
                serverThread1.setDatiForServer(new DatiForServer(temp2));
                serverThread2.setDatiForServer(new DatiForServer(temp1));
            }
        } catch (IOException e) {
            System.out.println("Errore durante l'istanza del server: " + e.getMessage());
            System.exit(1);
        }
    }

    public static void main(String[] args) {
        ServerT tcpServer = new ServerT();
        tcpServer.connetti();
    }

}
