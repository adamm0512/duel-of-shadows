import javax.swing.*;

public class Main { 
    public static void main(String[] args) {
        // Crea una finestra per il gioco
        JFrame frame = new JFrame("Fighting Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Crea un'istanza della schermata principale
        Schermata schermata = new Schermata();
        
        // Aggiungi la schermata principale alla finestra
        frame.setContentPane(schermata);

        // Imposta le dimensioni della finestra
        frame.setSize(1024, 576);
        frame.setVisible(true);
        schermata.requestFocusInWindow(); // Assicurati che la Schermata riceva il focus
    }
}