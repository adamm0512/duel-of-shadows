import java.awt.image.BufferedImage;
import java.awt.Graphics;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class SpriteSheet {
    private BufferedImage spriteSheet;
    private int frameWidth;
    private int frameHeight;

    public SpriteSheet(String path, int frameWidth, int frameHeight) {
        try {
            spriteSheet = ImageIO.read(new File(path));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.frameWidth = frameWidth;
        this.frameHeight = frameHeight;
    }

    public BufferedImage getFrame(int frameIndex) {
        int x = (frameIndex % (spriteSheet.getWidth() / frameWidth)) * frameWidth;
        int y = (frameIndex / (spriteSheet.getWidth() / frameWidth)) * frameHeight;
        return spriteSheet.getSubimage(x, y, frameWidth, frameHeight);
    }

    public int getTotalFrames() {
        return (spriteSheet.getWidth() / frameWidth) * (spriteSheet.getHeight() / frameHeight);
    }

    
}