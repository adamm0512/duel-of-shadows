import java.awt.*;

public class OnlineFighter {
    private int x, y;
    private int health = 100;
    private int maxHealth = 100; // Salute massima
    private String name;
    private boolean isJumping = false;
    private double jumpSpeed = 20; // Initial jump speed
    private double gravity = 1; // Gravity force
    private double verticalSpeed = 0; // Current vertical speed
    private double horizontalSpeed = 8; // Horizontal speed
    public boolean isAttack = false;
    private int width; // Width of the image
    private int height; // Height of the image
    private int currentFrame = 0; // Current frame
    private long lastFrameChange = 1; // Time of the last frame change
    private int frameDelay = 100; // Delay between frame changes (in milliseconds)
    private double scale;

    private SpriteSheet idleSheet; // Sprite sheet for idle animation
    private SpriteSheet runSheet; // Sprite sheet for run animation
    private SpriteSheet runBackSheet; // Sprite sheet for run back animation
    private SpriteSheet attackSheet; // Sprite sheet for attack animation

    private boolean isRunning = false; // Indicates if the character is running
    private ClientThread clientThread; // ClientThread instance for server communication

    public OnlineFighter(int x, int y, String name, String idlePath, String runPath, String runBackPath, String attackPath, int width, int height, double scale) {
        this.x = x;
        this.y = y;
        this.name = name;
        this.width = width;
        this.height = height;
        this.scale = scale;

        idleSheet = new SpriteSheet(idlePath, width, height);
        runSheet = new SpriteSheet(runPath, width, height);
        runBackSheet = new SpriteSheet(runBackPath, width, height);
        attackSheet = new SpriteSheet(attackPath, width, height);

        if (idleSheet.getFrame(0) == null) {
            System.out.println("Image for " + name + " not found!");
        }

        // Initialize the client connection
        clientThread = new ClientThread(new DatiForServer("initial data"));
        clientThread.connetti(); // Connect to the server
        new Thread(() -> clientThread.comunica()).start(); // Start communication in a new thread
    }

    public void draw(Graphics g) {
        // Determine which image to draw based on the current state
        Image currentImage;

        if (isAttack) {
            currentImage = attackSheet.getFrame(currentFrame);
        } else if (isRunning) {
            if (x > 0) {
                currentImage = runSheet.getFrame(currentFrame);
            } else {
                currentImage = runBackSheet.getFrame(currentFrame);
            }
        } else {
            currentImage = idleSheet.getFrame(currentFrame);
        }
        // Scale the image
        int scaledWidth = (int) (width * scale);
        int scaledHeight = (int) (height * scale);
        g.drawImage(currentImage, x, y, scaledWidth, scaledHeight, null);
    }
    public void update(int fighterHealth) {
        updateForServer(x, y, health, fighterHealth);
        updateFromServerData(clientThread.datiFromServer.fatti());
    }
    public void updateFromServerData(String serverData) {
        String[] data = serverData.split(",");
        this.x = Integer.parseInt(data[0]);
        this.y = Integer.parseInt(data[1]);
        this.health = Integer.parseInt(data[2]);

        // Update the state based on the new position
        if (x > 0) {
            isRunning = true;
        } else {
            isRunning = false;
        }

        // Change the frame of the animation
        long currentTime = System.currentTimeMillis();
        if (isAttack) {
            if (currentTime - lastFrameChange > frameDelay) {
                currentFrame++;
                if (currentFrame >= attackSheet.getTotalFrames()) {
                    currentFrame = 0; // Reset frame after completing the attack animation
                    isAttack = false; // Return to normal state
                }
                lastFrameChange = currentTime;
            }
        } else {
            if (isRunning) {
                if (currentTime - lastFrameChange > frameDelay) {
                    currentFrame = (currentFrame + 1) % runSheet.getTotalFrames();
                    lastFrameChange = currentTime;
                }
            } else {
                if (currentTime - lastFrameChange > frameDelay) {
                    currentFrame = (currentFrame + 1) % idleSheet.getTotalFrames();
                    lastFrameChange = currentTime;
                }
            }
        }
    }
    public void updateForServer(int x, int y, int health, int enemyHealth) {
        clientThread.datiForServer=new DatiForServer(x + "," + y + "," + health + "," + enemyHealth);
        
    }
    public void opponentAttack(Fighter player) {
        if (!isAttack && canAttack(player)) { // Solo se non si sta già attaccando
            isAttack = true; // Inizia l'attacco
            currentFrame = 0; // Reset del frame dell'animazione di attacco
            player.takeHit(); // Colpisci il giocatore
        }
    }
    
    public boolean canAttack(Fighter opponent) {
        return Math.abs(this.x - opponent.getX()) < 80; // Controlla se è in range
    }

    public void takeHit() {
        health -= 20; // Riduci la salute di 20
        if (health < 0) {
            health = 0; // Assicurati che la salute non scenda sotto zero
        }
        //aggionamento dati sul server
        
    }

    public int getHealth() {
        return health;
    }

    public String getName() {
        return name;
    }

    public void move(int dx) {
        x += dx;

        // Prevent movement beyond limits
        if (x <= 0) x = 0;
        if (x >= 1420) x = 1420; // Assuming 1420 is the right limit
    }

    public void attack(Fighter opponent) {
        if (!isAttack) { // Only if not already attacking
            if (Math.abs(this.x - opponent.getX()) < 80) { // Check if in range
                isAttack = true; // Start attack
                currentFrame = 0; // Reset attack animation frame
                opponent.takeHit();
            }
        }
    }

    public boolean isDefeated() {
        return health <= 0;
    }

    // Getter methods
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean isJumping() {
        return isJumping;
    }

    public double getJumpSpeed() {
        return jumpSpeed;
    }

    public double getGravity() {
        return gravity;
    }

    public double getVerticalSpeed() {
        return verticalSpeed;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public void setJumping(boolean isJumping) {
        this.isJumping = isJumping;
    }

    public void setJumpSpeed(double jumpSpeed) {
        this.jumpSpeed = jumpSpeed;
    }

    public void setGravity(double gravity) {
        this.gravity = gravity;
    }

    public void setVerticalSpeed(double verticalSpeed) {
        this.verticalSpeed = verticalSpeed;
    }

    public int getMaxHealth() {
        return maxHealth;
    }
    
}
