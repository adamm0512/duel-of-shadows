
public class TestClientServer {
    ClientThread client;
    
}
//main che avvia la classe Client