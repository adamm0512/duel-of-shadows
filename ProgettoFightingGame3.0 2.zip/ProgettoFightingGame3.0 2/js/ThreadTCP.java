//in teoria è finito, ma non sappiamo se funziona prima di finire tutto il resto del codice del server e di enemy e dei dati per il server
import java.io.*;
import java.net.*;
import java.util.*;

public class ThreadTCP extends Thread {
private final Socket clientSocket;
    private Scanner in; // dichiarazione variabile stream input giocatore 1
    private PrintWriter out; // dichiarazione variabile stream output giocatore 1
    public static DatiForServer datiForServer= new DatiForServer("0,0,100");
    public static String datifromServer;

    public ThreadTCP(Socket socket) {
        this.clientSocket = socket;
    }
    public void setDatiForServer(DatiForServer datiForServer){
        this.datiForServer=datiForServer;
    }
    public DatiForServer getDatiForServer(){
        return datiForServer;
    }
    public void setDatifromServer(String datifromServer){
        this.datifromServer=datifromServer;
    }
    public String getDatifromServer(){
        return datifromServer;
    }
    
    @Override
    public void run() {
        try {
            comunica();
        } catch (IOException e) {
            System.out.println("Errore durante la comunicazione: " + e.getMessage());
        }
    }

    public void comunica() throws IOException {
        try (Scanner in = new Scanner(clientSocket.getInputStream());
             PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
    
            while (true) {
                // Invia i dati al server
                out.println(datiForServer.fatti());
                System.out.println("Dati inviati al server: " + datiForServer.fatti());
    
                // Ricevi i dati aggiornati dal server
                if (in.hasNextLine()) {
                    String stringaRicevuta = in.nextLine();
                    System.out.println("Dati ricevuti dal server: " + stringaRicevuta);
    
                    // Aggiorna datiForServer con i dati ricevuti dal server
                    String[] datiArray = stringaRicevuta.split(",");
                    int x = Integer.parseInt(datiArray[0]);
                    int y = Integer.parseInt(datiArray[1]);
                    int health = Integer.parseInt(datiArray[2]);
                    int enemyHealth = Integer.parseInt(datiArray[3]);
                    datiForServer.update(x, y, health, enemyHealth);
                }
    
                // Aggiungi una pausa per evitare un ciclo infinito troppo veloce
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    System.out.println("Thread was interrupted, Failed to complete operation");
                }
            }
        } catch (IOException e) {
            System.out.println("Errore durante la comunicazione con il server: " + e.getMessage());
        }
    }
   
}
