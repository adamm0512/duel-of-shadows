//aggiungere a fighting game: Enemy enemy = new Enemy();
public class Enemy {
    private int timerCount;
    private int playerWidth;
    private int playerHeight;    
    private String name;
    int x;
    int y;
    private int health;
    private boolean isJumping;
    private double jumpSpeed;
    private double gravity;
    private double verticalSpeed;
    //conversione da json senza usare la libreria json quindi facendo degli split della classe generale all'avvio del gioco
    public Enemy(String json) {
        String[] parts = json.split(",");
        for (String part : parts) {
            String[] keyValue = part.split(":");
            String key = keyValue[0].replace("\"", "").trim();
            String value = keyValue[1].replace("\"", "").trim();
            switch (key) {
                case "timerCount":
                    timerCount = Integer.parseInt(value);
                    break;
                case "playerWidth":
                    playerWidth = Integer.parseInt(value);
                    break;
                case "playerHeight":
                    playerHeight = Integer.parseInt(value);
                    break;
                case "name":
                    name = value;
                    break;
                case "x":
                    x = Integer.parseInt(value);
                    break;
                case "y":
                    y = Integer.parseInt(value);
                    break;
                case "health":
                    health = Integer.parseInt(value);
                    break;
                case "isJumping":
                    isJumping = Boolean.parseBoolean(value);
                    break;
                case "jumpSpeed":
                    jumpSpeed = Double.parseDouble(value);
                    break;
                case "gravity":
                    gravity = Double.parseDouble(value);
                    break;
                case "verticalSpeed":
                    verticalSpeed = Double.parseDouble(value);
                    break;
            }
        }
    }
    //ora solo gli aggiornamenti per saperne la posizione senza tutti i dati superflui 
    public void update(String json) {
        String[] parts = json.split(",");
        for (String part : parts) {
            String[] keyValue = part.split(":");
            String key = keyValue[0].replace("\"", "").trim();
            String value = keyValue[1].replace("\"", "").trim();
            switch (key) {
                case "x":
                    x = Integer.parseInt(value);
                    break;
                case "y":
                    y = Integer.parseInt(value);
                    break;
                case "health":
                    health = Integer.parseInt(value);
                    break;
                case "isJumping":
                    isJumping = Boolean.parseBoolean(value);
                    break;
                case "jumpSpeed":
                    jumpSpeed = Double.parseDouble(value);
                    break;
                case "gravity":
                    gravity = Double.parseDouble(value);
                    break;
                case "verticalSpeed":
                    verticalSpeed = Double.parseDouble(value);
                    break;
            }
        }
    }
    //da fare tutti i movimenti e le modifiche di posizione implementate nel gioco qua ci sono soo di dati che verrannno scambiati sul server 
    public int getHealth() {
        return health;
    }
    public String getName(){
        return name;
    }
    public int getX() {
        return x;
    }
    public int getY(){
        return y;
    }
    public void takeHit() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'takeHit'");
    }
}
