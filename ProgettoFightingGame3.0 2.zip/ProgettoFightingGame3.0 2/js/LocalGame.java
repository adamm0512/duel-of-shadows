import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.*;

public class LocalGame extends JPanel implements ActionListener, KeyListener {
    private Timer timer;
    private Fighter player;
    private Fighter enemy;
    private int timerCount = 70000; // Timer in milliseconds
    private Image backgroundImage;
    private JProgressBar playerHealthBar;
    private JProgressBar enemyHealthBar;
    private JLabel timerLabel; // Label for the timer

    public LocalGame() {
        int playerWidth = 200; 
        int playerHeight = 200;
        double playerScale = 2.5;
        player = new Fighter(100, 350, "Mack", "img\\samuraiMack\\Idle.png", "img\\samuraiMack\\Run.png","img\\samuraiMack\\RunBack.png","img\\samuraiMack\\Attack1.png", playerWidth, playerHeight, playerScale);
        
        int enemyWidth = 200; 
        int enemyHeight = 200; 
        double enemyScale = 2.5;
        enemy = new Fighter(400, 350, "Kenji", "img\\kenji\\Idle.png", "img\\kenji\\RunBack.png","img\\kenji\\Run.png","img\\kenji\\Attack1.png", enemyWidth, enemyHeight, enemyScale);
        
        timer = new Timer(6, this); // Updates every 12 ms (about 60 FPS)
        setFocusable(true);
        requestFocusInWindow();
        addKeyListener(this);
        
        backgroundImage = new ImageIcon("img\\ghoul_resized.png").getImage();

        if (backgroundImage == null) {
            System.out.println("Background image not found!");
        }

        // Create a panel for health bars and timer
        JPanel healthPanel = new JPanel();
        healthPanel.setLayout(new GridLayout(1, 3)); // 1 row, 3 columns

        playerHealthBar = new JProgressBar(0, player.getMaxHealth());
        playerHealthBar.setValue(player.getHealth());
        playerHealthBar.setStringPainted(true);
        healthPanel.add(playerHealthBar);

        // Add a label for the timer
        timerLabel = new JLabel("Timer: " + String.format("%03d", timerCount / 1000)); // Show timer in seconds
        timerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        healthPanel.add(timerLabel);

        enemyHealthBar = new JProgressBar(0, enemy.getMaxHealth());
        enemyHealthBar.setValue(enemy.getHealth());
        enemyHealthBar.setStringPainted(true);
        healthPanel.add(enemyHealthBar);

        // Add the health bar and timer panel to the main panel
        setLayout(new BorderLayout());
        add(healthPanel, BorderLayout.NORTH);
    }

    public void startGame() {
        timer.start(); // Start the timer
        requestFocusInWindow(); // Ensure the panel has focus
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        player.draw(g);
        enemy.draw(g);
        
        // Color the health bars
        playerHealthBar.setForeground(getHealthColor(player.getHealth(), player.getMaxHealth()));
        enemyHealthBar.setForeground(getHealthColor(enemy.getHealth(), enemy.getMaxHealth()));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (timerCount > 0) {
            timerCount = timerCount - 10; // Decrease the timer by 1 ms
            player.update(); // Update the player
            enemy.update(); // Update the enemy

            // Update health bars
            playerHealthBar.setValue(player.getHealth());
            enemyHealthBar.setValue(enemy.getHealth());

            // Update the timer
            timerLabel.setText("Timer: " + String.format("%03d", timerCount / 1000)); // Show timer in seconds

            if (player.isDefeated() || enemy.isDefeated()) {
                timer.stop();
                determineWinner();
            }

            repaint();
        } else {
            timer.stop();
            determineWinner();
        }
    }

    private Color getHealthColor(int health, int maxHealth) {
        float ratio = (float) health / maxHealth;
        if (ratio > 0.5) {
            return Color.GREEN; // High health
        } else if (ratio > 0.2) {
            return Color.ORANGE; // Medium health
        } else {
            return Color.RED; // Low health
        }
    }

    private void determineWinner() {
        if (enemy.getHealth() <= 0) {
            JOptionPane.showMessageDialog(this, player.getName() + " Wins!");
        } else if (player.getHealth() <= 0) {
            JOptionPane.showMessageDialog(this, enemy.getName() + " Wins!");
        } else {
            String winner = player.getHealth() > enemy.getHealth() ? player.getName() + " Wins!" : enemy.getName() + " Wins!";
            JOptionPane.showMessageDialog(this, winner);
        }
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A: // Move player left
                player.move(-7);
                break;
            case KeyEvent.VK_D: // Move player right
                player.move(7);
                break;
            case KeyEvent.VK_W: // Player jump
                player.jump();
                break;
            case KeyEvent.VK_SPACE: // Player attack
                player.attack(enemy);
                break;
            case KeyEvent.VK_LEFT: // Move enemy left
                enemy.move(-7);
                break;
            case KeyEvent.VK_RIGHT: // Move enemy right
                enemy.move(7);
                break;
            case KeyEvent.VK_UP: // Enemy jump
                enemy.jump();
                break;
            case KeyEvent.VK_DOWN: // Enemy attack
                enemy.attack(player);
                break;
            
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_A: // Stop moving left
            case KeyEvent.VK_D: // Stop moving right
                player.move(0);
                break;
            case KeyEvent.VK_LEFT: // Stop enemy moving left
            case KeyEvent.VK_RIGHT: // Stop enemy moving right
                enemy.move(0);
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not implemented
    }
}