import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;

public class Schermata extends JPanel implements KeyListener {
    private BufferedImage backgroundImage;
    private BufferedImage messageImage; // Image for the message
    private Clip clip; // Audio clip

    public Schermata() {
        setFocusable(true);
        addKeyListener(this);
        loadBackgroundImage();
        loadMessageImage(); // Load the message image
        playAudio(".vs\\ProgettoFightingGame2\\musica\\musicaTitolo.wav"); // Update this path to your audio file
    }

    private void loadBackgroundImage() {
        try {
            backgroundImage = ImageIO.read(new File("img\\zebby.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadMessageImage() {
        try {
            messageImage = ImageIO.read(new File("img\\scritte2.png")); // Load the message image
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void playAudio(String filePath) {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(filePath));
            clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();

            // Add a listener to restart the audio when it finishes
            clip.addLineListener(new LineListener() {
                @Override
                public void update(LineEvent event) {
                    if (event.getType() == LineEvent.Type.STOP) {
                        clip.setFramePosition(0); // Reset to the beginning
                        clip.start(); // Restart the audio
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        } else {
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, getWidth(), getHeight());
        }

        // Draw the message image at the bottom
        if (messageImage != null) {
            int x = (getWidth() - messageImage.getWidth()) / 2; // Center the image horizontally
            int y = getHeight() - messageImage.getHeight() - 30; // Position it 30 pixels from the bottom
            g.drawImage(messageImage, x, y, this);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_T) {
            // Passa al pannello di gioco
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            FightingGame gamePanel = new FightingGame();
            frame.setContentPane(gamePanel);
            frame.revalidate();
            gamePanel.startGame(); // Assicurati di avviare il gioco qui
        }
        if (e.getKeyCode() == KeyEvent.VK_L) {
            // Passa al pannello di gioco
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            LocalGame gamePanelLocal = new LocalGame();
            frame.setContentPane(gamePanelLocal);
            frame.revalidate();
            gamePanelLocal.startGame(); // Assicurati di avviare il gioco qui
        }
        if (e.getKeyCode() == KeyEvent.VK_B) {
            // Passa al pannello di gioco
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            Battaglia gamePanelBattaglia = new Battaglia();
            frame.setContentPane(gamePanelBattaglia);
            frame.revalidate();
            gamePanelBattaglia.startGame(); // Assicurati di avviare il gioco qui
        }
        if (e.getKeyCode() == KeyEvent.VK_O) {
            // Passa al pannello di gioco
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            Online gamePanelOnline = new Online();
            frame.setContentPane(gamePanelOnline);
            frame.revalidate();
            gamePanelOnline.startGame(); // Assicurati di avviare il gioco qui
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Non implementato
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // Non implementato
    }
}
