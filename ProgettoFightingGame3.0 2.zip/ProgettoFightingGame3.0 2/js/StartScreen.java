import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class StartScreen extends JPanel implements KeyListener {
    private String message = "Premi ENTER per iniziare!";
    private BufferedImage backgroundImage;

    public StartScreen() {
        setFocusable(true);
        addKeyListener(this);
        loadBackgroundImage();
        playAudio("path/to/your/audiofile.wav"); // Update this path to your audio file
    }

    private void loadBackgroundImage() {
        try {
            backgroundImage = ImageIO.read(new File("img\\zebby.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void playAudio(String filePath) {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(filePath));
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        if (backgroundImage != null) {
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        } else {
            g.setColor(Color.BLACK);
            g.fillRect(0, 0, getWidth(), getHeight());
        }

        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 30));
        g.drawString(message, (getWidth() - g.getFontMetrics().stringWidth(message)) / 2, getHeight() / 2);

        // Aggiungi il messaggio per i tasti B e T
        g.setFont(new Font("Arial", Font.BOLD, 20));
        String tastoMessage = "Premi il tasto B per la modalità battaglia o il tasto T per la modalità tutorial";
        g.drawString(tastoMessage, (getWidth() - g.getFontMetrics().stringWidth(tastoMessage)) / 2, getHeight() - 30);
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            // Passa al pannello di gioco
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(this);
            FightingGame gamePanel = new FightingGame();
            frame.setContentPane(gamePanel);
            frame.revalidate();
            gamePanel.startGame(); // Assicurati di avviare il gioco qui
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Unimplemented method 'keyTyped'");
    }

    @Override
    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Unimplemented method 'keyReleased'");
    }
}
