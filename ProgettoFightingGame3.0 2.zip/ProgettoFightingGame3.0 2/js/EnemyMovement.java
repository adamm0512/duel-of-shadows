public class EnemyMovement{
    private int x;
    private int y;
    private int health = 100;
    private boolean isJumping = false;
    private double jumpSpeed = 20; // Initial jump speed
    private double gravity = 1; // Gravity force
    private double verticalSpeed = 0; // Current vertical speed
    private double horizontalSpeed = 5; // Horizontal speed

    public EnemyMovement(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void moveLeft() {
        x -= horizontalSpeed;
    }

    public void moveRight() {
        x += horizontalSpeed;
    }

    public void jump() {
        if (!isJumping) {
            isJumping = true;
            verticalSpeed = jumpSpeed; // Set initial vertical speed
        }
    }

    public void update() {
        if (isJumping) {
            y -= verticalSpeed; // Move up
            verticalSpeed -= gravity; // Apply gravity

            // Check if the enemy has landed
            if (y >= 546) { // Assuming 546 is the ground level
                y = 546; // Reset to ground level
                isJumping = false; // Jump completed
                verticalSpeed = 0; // Reset vertical speed
            }
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getHealth() {
        return health;
    }

    public void takeHit() {
        health -= 20;
        health -= 20;
        if (health < 0) {
            health = 0; // Prevent negative health
        }
    }
    //funzione update che prendere una stringa e la divide in parti per poi aggiornare i dati
    public void aggiornaDati(String dati) {
        String[] parts = dati.split(",");
        int px = Integer.parseInt(parts[0]);
        int py = Integer.parseInt(parts[1]);
        health = Integer.parseInt(parts[2]);
        

    }
    //funzione per verificare da che parte deve essere girato il nermico e se sta saltando confrontando i dati globali della classe e i dati passati a questa funzione
    public void aggiornaMovimento(int x,int y){
        if(this.x<x){
        //se la posizione x del nemico è minore di quella passata come parametro allora il nemico si gira a destra
        }else if(this.x>x){
        //se la posizione x del nemico è maggiore di quella passata come parametro allora il nemico si gira a sinistra
        }
        if(this.y>y){
        //se la posizione y del nemico è maggiore di quella passata come parametro allora il nemico sta saltando
        }

    }

}
