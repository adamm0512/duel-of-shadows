//in teoria è finito, ma non sappiamo se funziona prima di finire tutto il resto del codice del server e di enemy e dei dati per il server
import java.io.*;
import java.net.*;
import java.util.*;
//aggiungere a fighting game : ClientThread cliente = new ClientThread(enemy, DatiForServer);
//cliente.connetti();
//cliente.comunica();
public class ClientThread {
 private String nomeServer = "localhost"; // nome server locale
    private int portaServer = 6789; // porta per il servizio di connessione
    private Socket clientSocket;
    private Scanner in; // dichiarazione variabile stream input
    private PrintWriter out; // dichiarazione variabile stream output
    EnemyMovement enemyMovement;
    DatiForServer datiForServer;
    DatiForServer datiFromServer;
    ClientThread( DatiForServer datiForServer/*, EnemyMovement enemyMovement*/) {
        //this.enemyMovement = enemyMovement;
        this.datiForServer = datiForServer;
        
    }

    public Socket connetti() { // metodo per connettersi al server
        System.out.println("CLIENT partito e in esecuzione ...");
        try {
            InetAddress indServer = InetAddress.getByName(nomeServer);
            clientSocket = new Socket(indServer, portaServer);
        } catch (UnknownHostException e) {
            System.out.println("Host sconosciuto: " + e.getMessage());
            System.exit(1);
        } catch (IOException e) {
            System.out.println("Errore durante l'istanza del server: " + e.getMessage());
            System.exit(1);
        }
        return clientSocket;
    }
    public void comunica() { // metodo per comunicare con il server
        try (Scanner tastiera = new Scanner(System.in)) {
            while (true) {
                try {
                    // associo due oggetti al socket del client per effettuare la scrittura e la lettura
                    in = new Scanner(clientSocket.getInputStream());
                    out = new PrintWriter(clientSocket.getOutputStream(), true);
                    out.println(datiForServer.fatti()); // invio stringa al Server

                    // leggo la risposta dal server
                    String ricevuta = in.next(); // leggo stringa ricevuta dal Server
                    enemyMovement.aggiornaDati(ricevuta);
                    System.out.println("Risposta dal Server:\n" + ricevuta);
                    System.out.println("------------------------------------------------------------------------------- ");
                    datiFromServer = new DatiForServer(ricevuta);


                    if ("fine".equalsIgnoreCase(ricevuta)) {
                        System.out.println("CLIENT: termina elaborazione e chiude connessione con il server");
                        break;
                    }
                } catch (IOException e) {
                    System.out.println("Errore durante la comunicazione con il server: " + e.getMessage());
                    break;
                }
            }
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
                if (clientSocket != null && !clientSocket.isClosed()) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                System.out.println("Errore durante la chiusura del socket: " + e.getMessage());
            }
        }
    }
}
