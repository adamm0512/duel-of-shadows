public class DatiForServer {
    private int x;
    private int y;
    private int health;
    private int enemyHealth;
    // Costruttore
    public DatiForServer(String dati) {
        String[] datiArray = dati.split(",");
        this.x = Integer.parseInt(datiArray[0]);
        this.y = Integer.parseInt(datiArray[1]);
        this.health = Integer.parseInt(datiArray[2]);
        this.enemyHealth = Integer.parseInt(datiArray[3]);
    }
    public void update (int x, int y, int health, int enemyHealth) {
        //aggiornamento dati
        this.x = x;
        this.y = y;
        this.health = health;
        this.enemyHealth = enemyHealth;
    }
    // Getter methods
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
    public int getHealth() {
        return health;
    }
    public int getEnemyHealth() {
        return enemyHealth;
    }
    // Setter methods
    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }
    public void setHealth(int health) {
        this.health = health;
    }
    public void setEnemyHealth(int enemyHealth) {
        this.enemyHealth = enemyHealth;
    }
    //per altri
    public String fatti(){
        return (x+","+y+","+health+","+enemyHealth);
    }
    
}
